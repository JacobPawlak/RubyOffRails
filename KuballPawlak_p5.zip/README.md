# RubyOffRails
## CS316 Web Programming Project 5 - Ruby on Rails FanXelk

Jacob Pawlak and Chelsea Kuball 

CS316 Project 5

December 9th, 2017

### we implimented all of the required parts, a - d

a) fully implemented 
b) fully implemented
c) fully implemented
d) fully implemented
